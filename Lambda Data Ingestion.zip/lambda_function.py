import requests
import boto3
from datetime import datetime, timedelta

def lambda_handler(event, context):
    s3 = boto3.client("s3")
    bucket_name = "revana-data-analysis-project"  

    # Define 1 year ago
    end = datetime.utcnow()
    start = end - timedelta(days=365)

    # Start from 1st of the "start month"
    current = start.replace(day=1)

    while current < end:
        # Move to 1st of the next month
        if current.month == 12:
            next_month = current.replace(year=current.year + 1, month=1, day=1)
        else:
            next_month = current.replace(month=current.month + 1, day=1)

        # API request for that month
        url = "https://earthquake.usgs.gov/fdsnws/event/1/query"
        params = {
            "format": "geojson",
            "starttime": current.strftime("%Y-%m-%d"),
            "endtime": next_month.strftime("%Y-%m-%d")
        }

        print(f"Fetching {params['starttime']} to {params['endtime']}")
        response = requests.get(url, params=params, timeout=60)
        response.raise_for_status()

        # Save to S3 with monthly filename
        file_key = f"earthquakes/{current.strftime('%Y-%m')}.json"
        s3.put_object(Bucket=bucket_name, Key=file_key, Body=response.content)

        print(f"Uploaded {file_key}")

        # Move to next month
        current = next_month

    return {
        "statusCode": 200,
        "body": "Uploaded monthly earthquake data for past year."
    }
